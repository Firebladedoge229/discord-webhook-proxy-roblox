<img src="/public/img/logo.svg" width="128" align="right">

# WebhookProxy
A Discord webhook proxy, primarily for Roblox games.

# Why?
Discord banned Roblox from making webhooks again, primarily for abuse purposes. This proxy works around that.
