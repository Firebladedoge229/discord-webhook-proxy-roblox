-- CreateTable
CREATE TABLE "BannedWebhook" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "reason" TEXT NOT NULL
);
