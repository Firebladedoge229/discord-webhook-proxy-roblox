-- CreateTable
CREATE TABLE "Stats" (
    "name" TEXT NOT NULL PRIMARY KEY,
    "value" INTEGER NOT NULL
);
