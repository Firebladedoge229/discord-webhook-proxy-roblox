-- CreateTable
CREATE TABLE "WebhooksSeen" (
    "id" TEXT NOT NULL PRIMARY KEY
);
